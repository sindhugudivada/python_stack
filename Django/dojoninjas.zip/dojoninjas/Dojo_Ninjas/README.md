# Dojo_Ninjas
Django ORM based project
